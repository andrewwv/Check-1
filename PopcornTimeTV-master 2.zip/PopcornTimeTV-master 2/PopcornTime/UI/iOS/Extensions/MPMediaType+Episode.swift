

import Foundation
import MediaPlayer.MPMediaItem

extension MPMediaType {
    static let episode = MPMediaType(rawValue: 1 << 14)
}

