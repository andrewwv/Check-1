

import Foundation

class TVDescriptionViewController: UIViewController {
    
    @IBOutlet var textView: UITextView!
    @IBOutlet var titleLabel: UILabel!
}
