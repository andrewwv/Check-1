

import Foundation

extension UIActivityIndicatorView.Style {
    static let grey = UIActivityIndicatorView.Style(rawValue: 2)!
}
