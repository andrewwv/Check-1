

#ifndef PopcornTimetvOS_Bridging_Header_h
#define PopcornTimetvOS_Bridging_Header_h

#import <TVVLCKit/TVVLCKit.h>
#import "NSObject+Swift_Observer.h"
#import <ifaddrs.h>

#endif


