

#ifndef PopcornTimeiOS_Bridging_Header_h
#define PopcornTimeiOS_Bridging_Header_h

#import <MobileVLCKit/MobileVLCKit.h>
#import <GoogleCast/GoogleCast.h>
#import <ifaddrs.h>
#import "NSObject+Swift_Observer.h"

#endif
