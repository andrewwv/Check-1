

import Foundation

protocol Object: class {
    
    static func awake()
}
