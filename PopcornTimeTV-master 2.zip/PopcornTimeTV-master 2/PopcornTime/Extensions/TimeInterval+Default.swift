

import Foundation

extension TimeInterval {
    static let `default` = 0.33
}
