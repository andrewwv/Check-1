

import Foundation

public let MPMediaItemPropertySummary = "summary"
public let MPMediaItemPropertyShow = "show"
public let MPMediaItemPropertyEpisode = "episode"
public let MPMediaItemPropertySeason = "season"
public let MPMediaItemPropertyBackgroundArtwork = "backgroundArtwork"
